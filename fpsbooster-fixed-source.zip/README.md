# FPSBooster

A lightweight client-side FPS optimization mod for Minecraft Java Edition 1.21.11 using Fabric.

## Target
- Minecraft 1.21.11
- Fabric Loader 0.18.1+
- Java 21
- Fabric API 0.141.6+1.21.11
- Fabric Loom 1.14.10

## What it does
FPSBooster applies conservative client-side visual optimizations on startup:
- Disables clouds
- Reduces particles
- Disables entity shadows

It does not change gameplay or server behavior.

## Build
Use Gradle 9.2.1+ with Java 21:

    gradle build --no-daemon

The compiled JAR will be in `build/libs/`.
