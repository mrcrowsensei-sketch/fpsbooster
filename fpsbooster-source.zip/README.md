# FPSBooster

A lightweight client-side FPS helper for Minecraft Java 1.21.11 using Fabric.

Made by MrCrowSensei.

## What it does
- Disables cloud rendering.
- Reduces particles to Minimal.
- Disables entity shadows.
- Applies the settings once after the player joins.

This is a conservative optimization mod. It cannot guarantee a specific FPS because performance depends on the device, GPU, render distance, shaders, world and other mods.

## Build
Requires Java 21 and Fabric Loom. The GitHub Actions workflow can extract this project ZIP and run `gradle build --no-daemon`.

## Target
- Minecraft Java Edition 1.21.11
- Fabric Loader 0.18.1+
- Fabric API 0.141.6+1.21.11
