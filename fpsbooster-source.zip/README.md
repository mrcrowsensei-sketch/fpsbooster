# FPSBooster

**Fabric client-side FPS optimization mod for Minecraft 1.21.11.**

Made by **MrCrowSensei**.

### What it does
FPSBooster applies lightweight performance-oriented client settings:
- Disables clouds
- Reduces particles
- Disables entity shadows
- Uses no gameplay/server-side changes

### Build
Use Java 21 and Gradle/Fabric Loom. Run:

`./gradlew build`

The JAR will be in `build/libs/`.

### Important
FPS gains depend on your device, GPU, render distance, resolution, shaders, world and other mods. No mod can guarantee a specific FPS such as 100+.
