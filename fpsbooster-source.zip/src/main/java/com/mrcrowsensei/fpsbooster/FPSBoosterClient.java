package com.mrcrowsensei.fpsbooster;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.particle.ParticlesMode;

public class FPSBoosterClient implements ClientModInitializer {
    private static boolean applied = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(FPSBoosterClient::onClientTick);
    }

    private static void onClientTick(MinecraftClient client) {
        if (applied || client.player == null) return;

        applied = true;
        client.options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        client.options.getParticles().setValue(ParticlesMode.MINIMAL);
        client.options.getEntityShadows().setValue(false);
    }
}
