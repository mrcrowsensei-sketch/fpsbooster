package com.mrcrowsensei.fpsbooster;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

public class FPSBoosterClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // Conservative automatic optimizations. These do not change gameplay.
            // Only apply once to avoid repeatedly writing options.
            if (!Boolean.TRUE.equals(client.getWindow().getHandle() == 0L)) {
                applyOptimizations(client);
            }
        });
    }

    private static boolean applied = false;

    private static void applyOptimizations(MinecraftClient client) {
        if (applied) return;
        applied = true;

        // Favor performance while keeping the game visually usable.
        client.options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        client.options.getParticles().setValue(ParticlesMode.DECREASED);
        client.options.getEntityShadows().setValue(false);
    }
}
